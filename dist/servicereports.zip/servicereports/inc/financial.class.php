<?php
/**
 * Lógica do bloco "Gestão financeira": lê os dados financeiros do plugin
 * managedservices (valores historizados) e agrega em KPIs, rankings e relatórios.
 *
 * "Valor atual" de uma dimensão = registro mais recente (por record_date)
 * de cada (serviço, tipo, ativo, usuário).
 *
 * Sub-abas (paridade com o vReports original):
 *   - Dashboards  → getKpis() + gráficos.
 *   - Relatórios  → 2 relatórios:
 *       1  Extrato financeiro        (detalhamento por entidade/serviço)
 *       2  Faturamento financeiro    (resumo do total faturado no período)
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

class PluginServicereportsFinancial
{
    private const MS_TABLE  = 'glpi_plugin_managedservices_managedservices';
    private const FV_TABLE  = 'glpi_plugin_managedservices_financialvalues';
    private const CA_TABLE  = 'glpi_plugin_managedservices_coveredassets';
    private const MS_FK     = 'plugin_managedservices_managedservices_id';

    /** O plugin managedservices está instalado? */
    public static function isAvailable(): bool
    {
        global $DB;
        return $DB->tableExists(self::MS_TABLE) && $DB->tableExists(self::FV_TABLE);
    }

    /**
     * Subconsulta com o valor mais recente de cada dimensão financeira,
     * já restrita às entidades ativas (via join ao serviço).
     */
    private static function latestValuesSql(): string
    {
        $ms  = self::MS_TABLE;
        $fv  = self::FV_TABLE;
        // A restrição precisa referenciar o **alias** `ms` (e não o nome da tabela):
        // com a sessão restrita a uma entidade o GLPI gera `tabela`.`entities_id`,
        // que não existe na consulta aliasada — e a query inteira falhava.
        $ent = getEntitiesRestrictRequest('AND', 'ms');
        return "SELECT fv.*, ms.entities_id AS ms_entity, ms.users_id AS ms_client,
                       ROW_NUMBER() OVER (
                           PARTITION BY fv.plugin_managedservices_managedservices_id, fv.value_type, fv.itemtype, fv.items_id, fv.users_id
                           ORDER BY fv.record_date DESC, fv.id DESC
                       ) AS rn
                FROM `$fv` fv
                INNER JOIN `$ms` ms ON ms.id = fv.plugin_managedservices_managedservices_id
                WHERE 1 $ent";
    }

    private static function scalar(string $sql): float
    {
        global $DB;
        $res = $DB->doQuery($sql);
        $row = $DB->fetchAssoc($res);
        return (float) ($row['v'] ?? 0);
    }

    // =====================================================================
    //  Dashboards
    // =====================================================================

    /**
     * @return array<int,array{title:string,value:string,icon:string,accent:string}>
     */
    public static function getKpis(): array
    {
        global $DB;

        $ms  = self::MS_TABLE;
        $ent = getEntitiesRestrictRequest('AND', $ms);
        $latest = self::latestValuesSql();

        // Receita prevista = valores recorrentes (mensal, por classe de ativo, por
        // usuário). O valor/hora é uma tarifa, não receita — só vira dinheiro no
        // extrato, multiplicado pelas horas de tarefa; fica de fora aqui.
        $receitaPrevista = self::scalar("SELECT COALESCE(SUM(value),0) AS v FROM ($latest) l WHERE rn=1 AND value_type <> 'hourly'");
        $receitaMensal   = self::scalar("SELECT COALESCE(SUM(value),0) AS v FROM ($latest) l WHERE rn=1 AND value_type='monthly'");
        $mediaMensal     = self::scalar("SELECT COALESCE(AVG(value),0) AS v FROM ($latest) l WHERE rn=1 AND value_type='monthly'");
        $receitaAtivos   = self::scalar("SELECT COALESCE(SUM(value),0) AS v FROM ($latest) l WHERE rn=1 AND value_type='perclass'");
        $clientes        = self::scalar("SELECT COUNT(DISTINCT users_id) AS v FROM `$ms` WHERE users_id>0 $ent");
        $servicos        = self::scalar("SELECT COUNT(*) AS v FROM `$ms` WHERE 1 $ent");

        return [
            ['title' => __('Receita prevista', 'servicereports'), 'value' => self::money($receitaPrevista), 'icon' => 'ti ti-trending-up', 'accent' => 'primary'],
            ['title' => __('Receita de ativos cobertos', 'servicereports'), 'value' => self::money($receitaAtivos), 'icon' => 'ti ti-device-desktop', 'accent' => 'primary'],
            ['title' => __('Valor médio mensal dos serviços', 'servicereports'), 'value' => self::money($mediaMensal), 'icon' => 'ti ti-calculator', 'accent' => 'primary'],
            ['title' => __('Receita mensal dos serviços', 'servicereports'), 'value' => self::money($receitaMensal), 'icon' => 'ti ti-cash', 'accent' => 'primary'],
            ['title' => __('Clientes', 'servicereports'), 'value' => (string) (int) $clientes, 'icon' => 'ti ti-users', 'accent' => 'info'],
            ['title' => __('Serviços', 'servicereports'), 'value' => (string) (int) $servicos, 'icon' => 'ti ti-server-cog', 'accent' => 'info'],
        ];
    }

    /**
     * Top 10 receita prevista por entidade.
     *
     * @return array<int,array{label:string,value:float}>
     */
    public static function getRevenueByEntity(): array
    {
        global $DB;
        $latest = self::latestValuesSql();
        $sql = "SELECT ms_entity AS entity, SUM(value) AS total
                FROM ($latest) l WHERE rn=1 AND value_type <> 'hourly'
                GROUP BY ms_entity ORDER BY total DESC LIMIT 10";
        $out = [];
        foreach ($DB->request($sql) as $row) {
            $out[] = ['label' => Dropdown::getDropdownName('glpi_entities', (int) $row['entity']), 'value' => (float) $row['total']];
        }
        return $out;
    }

    /**
     * Top 10 valor médio por tipo de ativo (dimensão perclass).
     *
     * @return array<int,array{label:string,value:float}>
     */
    public static function getAvgByAssetType(): array
    {
        global $DB;
        $latest = self::latestValuesSql();
        $sql = "SELECT itemtype, AVG(value) AS media
                FROM ($latest) l WHERE rn=1 AND value_type='perclass' AND itemtype IS NOT NULL AND itemtype<>''
                GROUP BY itemtype ORDER BY media DESC LIMIT 10";
        $out = [];
        foreach ($DB->request($sql) as $row) {
            $itemtype = $row['itemtype'];
            $label = (class_exists($itemtype)) ? $itemtype::getTypeName(1) : $itemtype;
            $out[] = ['label' => $label, 'value' => (float) $row['media']];
        }
        return $out;
    }

    // =====================================================================
    //  Relatórios — coleta (Extrato financeiro / Faturamento)
    // =====================================================================

    /** Valor mais recente de um value_type escalar (monthly/hourly) do serviço. */
    private static function latestScalarValue(int $sid, string $type): float
    {
        global $DB;
        $fv = self::FV_TABLE;
        $type = $DB->escape($type);
        $res = $DB->doQuery(
            "SELECT value FROM `$fv`
             WHERE " . self::MS_FK . " = $sid AND value_type = '$type'
             ORDER BY record_date DESC, id DESC LIMIT 1"
        );
        $row = $DB->fetchAssoc($res);
        return (float) ($row['value'] ?? 0);
    }

    /** Coluna do "tipo" (…types_id) para casar um ativo coberto a um valor perclass. */
    private static function assetTypeField(string $itemtype): ?string
    {
        $map = [
            'Computer'           => 'computertypes_id',
            'Monitor'            => 'monitortypes_id',
            'Printer'            => 'printertypes_id',
            'NetworkEquipment'   => 'networkequipmenttypes_id',
            'Peripheral'         => 'peripheraltypes_id',
            'Phone'              => 'phonetypes_id',
            'Rack'               => 'racktypes_id',
            'PDU'                => 'pdutypes_id',
            'Passivedcequipment' => 'passivedcequipmenttypes_id',
        ];
        return $map[$itemtype] ?? null;
    }

    /**
     * Valor monetário de ativos do serviço: para cada ativo coberto, casa o
     * valor "perclass" (por tipo) com o tipo do ativo e soma.
     */
    private static function serviceAssetValue(int $sid): float
    {
        global $DB;

        // Últimos valores perclass do serviço, indexados por "ItemtypeType#idDoTipo".
        $fv = self::FV_TABLE;
        $perclass = [];
        $res = $DB->doQuery(
            "SELECT itemtype, items_id, value FROM (
                SELECT itemtype, items_id, value,
                       ROW_NUMBER() OVER (PARTITION BY itemtype, items_id ORDER BY record_date DESC, id DESC) rn
                FROM `$fv`
                WHERE " . self::MS_FK . " = $sid AND value_type = 'perclass'
             ) t WHERE rn = 1"
        );
        while ($r = $DB->fetchAssoc($res)) {
            $perclass[$r['itemtype'] . '#' . (int) $r['items_id']] = (float) $r['value'];
        }
        if (empty($perclass)) {
            return 0.0;
        }

        $total = 0.0;
        $assets = $DB->request([
            'FROM'  => self::CA_TABLE,
            'WHERE' => [self::MS_FK => $sid, 'is_deleted' => 0],
        ]);
        foreach ($assets as $a) {
            $itemtype = (string) $a['itemtype'];
            $field    = self::assetTypeField($itemtype);
            if (!$field || !class_exists($itemtype)) {
                continue;
            }
            $tbl = getTableForItemType($itemtype);
            $row = $DB->request(['SELECT' => $field, 'FROM' => $tbl, 'WHERE' => ['id' => (int) $a['items_id']]])->current();
            $typeId = (int) ($row[$field] ?? 0);
            $key    = $itemtype . 'Type#' . $typeId;
            $total += $perclass[$key] ?? 0.0;
        }
        return $total;
    }

    /**
     * Categoria do serviço + **toda a sua descendência** na árvore de categorias.
     * Ex.: "Suporte Avançado" traz também "Suporte Avançado > Active Directory >
     * Criação / Alteração de GPO".
     *
     * @return int[]
     */
    public static function categoryTreeIds(int $catId): array
    {
        if ($catId <= 0) {
            return [];
        }
        // getSonsOf() devolve a própria categoria + todas as filhas (recursivo).
        $ids = array_map('intval', array_values(getSonsOf('glpi_itilcategories', $catId)));
        return $ids ?: [$catId];
    }

    /**
     * IDs de chamados vinculados ao serviço: por categoria do serviço — incluindo
     * as subcategorias (glpi_tickets.itilcategories_id ∈ árvore da categoria) —
     * e/ou por ativo coberto (glpi_items_tickets). A busca por categoria respeita
     * a entidade do serviço (mais as filhas, se o serviço for recursivo).
     *
     * @return int[]
     */
    private static function linkedTicketIds(int $sid, int $entity, int $catId, bool $recursive = false): array
    {
        global $DB;
        $ids = [];

        // Serviço recursivo cobre também as entidades filhas (mesma semântica
        // do `is_recursive` do GLPI); senão, só a entidade do próprio serviço.
        $entities = $recursive
            ? array_map('intval', array_values(getSonsOf('glpi_entities', $entity)))
            : [$entity];

        $cats = self::categoryTreeIds($catId);
        if (!empty($cats)) {
            $res = $DB->request([
                'SELECT' => 'id',
                'FROM'   => 'glpi_tickets',
                'WHERE'  => ['itilcategories_id' => $cats, 'entities_id' => $entities, 'is_deleted' => 0],
            ]);
            foreach ($res as $r) {
                $ids[(int) $r['id']] = true;
            }
        }

        $ca = self::CA_TABLE;
        $res = $DB->doQuery(
            "SELECT DISTINCT it.tickets_id AS id
             FROM `glpi_items_tickets` it
             INNER JOIN `$ca` ca ON ca.itemtype = it.itemtype AND ca.items_id = it.items_id
             WHERE ca.`" . self::MS_FK . "` = $sid AND ca.is_deleted = 0"
        );
        while ($r = $DB->fetchAssoc($res)) {
            $ids[(int) $r['id']] = true;
        }

        return array_keys($ids);
    }

    /**
     * Chamados do serviço faturáveis no período: os **fechados** dentro dele
     * (`glpi_tickets.closedate` entre início e fim). Regra de negócio da Instant
     * (2026-08-25): o chamado só vira dinheiro quando encerra, e aí entra com
     * **todas** as suas tarefas, inclusive as de meses anteriores — um chamado
     * aberto em 09/10, com tarefas em 11/10, 02/11 e 04/11 e fechado em 14/11
     * não aparece no extrato de outubro e soma as três horas no de novembro.
     * Chamado em aberto (ou Solucionado sem fechar) não entra em extrato nenhum.
     *
     * Devolve o que a listagem do extrato exibe: tipo, requerente, abertura,
     * fechamento e o tempo **total** de tarefas do chamado.
     *
     * @param int[] $ticketIds
     * @return array<int,array<string,mixed>>
     */
    private static function ticketsInPeriod(array $ticketIds, string $startDt, string $endDt): array
    {
        global $DB;
        if (empty($ticketIds)) {
            return [];
        }
        $in = implode(',', array_map('intval', $ticketIds));
        $s  = $DB->escape($startDt);
        $e  = $DB->escape($endDt);

        // Tempo de tarefas por chamado: **todas** as tarefas, sem filtro de data —
        // quem delimita o período é o fechamento do chamado (ver docblock).
        $seconds = [];
        $res = $DB->doQuery(
            "SELECT tickets_id, COALESCE(SUM(actiontime),0) AS t
             FROM `glpi_tickettasks`
             WHERE tickets_id IN ($in)
             GROUP BY tickets_id"
        );
        while ($r = $DB->fetchAssoc($res)) {
            $seconds[(int) $r['tickets_id']] = (int) $r['t'];
        }

        // Requerentes (pode haver mais de um por chamado).
        $requesters = [];
        $res = $DB->doQuery(
            "SELECT tickets_id, users_id
             FROM `glpi_tickets_users`
             WHERE tickets_id IN ($in) AND type = " . CommonITILActor::REQUESTER . " AND users_id > 0"
        );
        while ($r = $DB->fetchAssoc($res)) {
            $requesters[(int) $r['tickets_id']][] = getUserName((int) $r['users_id']);
        }

        // Período = data de **fechamento** (não a de abertura): o chamado é
        // faturado no mês em que encerrou. `closedate` NULL (aberto/pendente/
        // apenas solucionado) fica de fora — o BETWEEN já descarta.
        $res = $DB->doQuery(
            "SELECT id, name, date, closedate, solvedate, status, type, itilcategories_id
             FROM `glpi_tickets`
             WHERE id IN ($in) AND is_deleted = 0 AND closedate BETWEEN '$s' AND '$e'
             ORDER BY closedate DESC"
        );
        $out = [];
        while ($r = $DB->fetchAssoc($res)) {
            $tid = (int) $r['id'];
            $out[] = [
                'id'        => $tid,
                'name'      => (string) $r['name'],
                'type'      => (int) $r['type'],
                'date'      => (string) $r['date'],
                'closedate' => (string) ($r['closedate'] ?: $r['solvedate'] ?: ''),
                'status'    => (int) $r['status'],
                'cat'       => (int) $r['itilcategories_id'],
                'requester' => implode(', ', $requesters[$tid] ?? []),
                'seconds'   => $seconds[$tid] ?? 0,
            ];
        }
        return $out;
    }

    /** Ativos cobertos do serviço (para a listagem do extrato). */
    private static function serviceCoveredAssets(int $sid): array
    {
        global $DB;
        $out = [];
        $assets = $DB->request([
            'FROM'  => self::CA_TABLE,
            'WHERE' => [self::MS_FK => $sid, 'is_deleted' => 0],
            'ORDER' => 'itemtype',
        ]);
        foreach ($assets as $a) {
            $itemtype = (string) $a['itemtype'];
            $name     = "#{$a['items_id']}";
            if (class_exists($itemtype)) {
                $obj = new $itemtype();
                if ($obj->getFromDB((int) $a['items_id'])) {
                    $name = $obj->getName();
                }
            }
            $typename = class_exists($itemtype) ? $itemtype::getTypeName(1) : $itemtype;
            $out[] = [
                'itemtype'   => $itemtype,
                'items_id'   => (int) $a['items_id'],
                'typename'   => $typename,
                'name'       => $name,
                'entry_date' => (string) ($a['contract_entry_date'] ?? ''),
            ];
        }
        return $out;
    }

    /**
     * Extrato financeiro completo: por entidade → por serviço.
     *
     * Componentes por serviço:
     *   - mensal   : último valor "monthly".
     *   - ativos   : soma dos valores "perclass" casados aos ativos cobertos.
     *   - categoria: valor por categoria de chamado — sem modelo de dados no
     *                managedservices (o vReports original tinha fonte própria); 0.
     *   - extras   : valores extras ligados a chamados — idem; 0.
     *   - tarefas  : tempo (Σ actiontime de **todas** as tarefas dos chamados
     *                fechados no período) × valor/hora ("hourly").
     *   - total    : soma dos componentes.
     *
     * @return array<int,array{name:string,summary:array<string,float>,services:array}>
     */
    public static function getExtrato(string $startDt, string $endDt): array
    {
        global $DB;

        $ent = getEntitiesRestrictRequest('AND', self::MS_TABLE);
        $res = $DB->doQuery(
            "SELECT id, name, entities_id, is_recursive, users_id, itilcategories_id
             FROM `" . self::MS_TABLE . "`
             WHERE 1 $ent
             ORDER BY entities_id, name"
        );

        $byEntity = [];
        while ($svc = $DB->fetchAssoc($res)) {
            $sid    = (int) $svc['id'];
            $entId  = (int) $svc['entities_id'];
            $catId  = (int) $svc['itilcategories_id'];

            $mensal = self::latestScalarValue($sid, 'monthly');
            $ativos = self::serviceAssetValue($sid);
            $hourly = self::latestScalarValue($sid, 'hourly');

            $linked   = self::linkedTicketIds($sid, $entId, $catId, (bool) $svc['is_recursive']);
            $tickets  = self::ticketsInPeriod($linked, $startDt, $endDt);
            // Custos por chamado: hora = tempo de tarefas × valor/hora do serviço;
            // categoria = sem modelo de dados no managedservices (ver docblock) → 0.
            $seconds = 0;
            foreach ($tickets as &$t) {
                $t['cost_hour']  = $hourly > 0 ? ($t['seconds'] / 3600.0) * $hourly : 0.0;
                $t['cost_cat']   = 0.0;
                $t['cost_total'] = $t['cost_hour'] + $t['cost_cat'];
                $seconds        += (int) $t['seconds'];
            }
            unset($t);
            // O total sai da soma dos chamados listados (e não de uma consulta
            // própria): garante que o cabeçalho bata com a listagem.
            $taskVal = $hourly > 0 ? ($seconds / 3600.0) * $hourly : 0.0;

            $categoria = 0.0; // sem modelo de dados (ver docblock)
            $extras    = 0.0; // sem modelo de dados (ver docblock)
            $total     = $mensal + $ativos + $categoria + $extras + $taskVal;

            if (!isset($byEntity[$entId])) {
                $byEntity[$entId] = [
                    'name'     => self::entityName($entId),
                    'summary'  => ['total' => 0.0, 'fixos' => 0.0, 'categorias' => 0.0, 'hora' => 0.0, 'extras' => 0.0, 'ativos' => 0.0, 'segundos' => 0],
                    'services' => [],
                ];
            }

            $byEntity[$entId]['services'][] = [
                'id'           => $sid,
                'name'         => (string) $svc['name'],
                'cat'          => $catId,
                'mensal'       => $mensal,
                'ativos'       => $ativos,
                'categoria'    => $categoria,
                'extras'       => $extras,
                'task_seconds' => $seconds,
                'task_value'   => $taskVal,
                'total'        => $total,
                'coveredassets'=> self::serviceCoveredAssets($sid),
                'tickets'      => $tickets,
            ];

            $byEntity[$entId]['summary']['fixos']      += $mensal;
            $byEntity[$entId]['summary']['ativos']     += $ativos;
            $byEntity[$entId]['summary']['categorias'] += $categoria;
            $byEntity[$entId]['summary']['hora']       += $taskVal;
            $byEntity[$entId]['summary']['extras']     += $extras;
            $byEntity[$entId]['summary']['total']      += $total;
            $byEntity[$entId]['summary']['segundos']   += $seconds;
        }

        return $byEntity;
    }

    /**
     * Nome **curto** da entidade (só a folha, sem a árvore de pais).
     * O `Dropdown::getDropdownName` devolveria o completename
     * ("Instant > Standard > Uniletra"); no extrato queremos só "Uniletra".
     */
    public static function entityName(int $entityId): string
    {
        global $DB;

        if ($entityId <= 0) {
            // Entidade raiz: deixa o core resolver (nome traduzido).
            return Dropdown::getDropdownName('glpi_entities', $entityId);
        }
        $row  = $DB->request(['SELECT' => 'name', 'FROM' => 'glpi_entities', 'WHERE' => ['id' => $entityId]])->current();
        $name = (string) ($row['name'] ?? '');
        return $name !== '' ? $name : Dropdown::getDropdownName('glpi_entities', $entityId);
    }

    /** Nº total de serviços do extrato (base da paginação). */
    public static function countServices(array $extrato): int
    {
        $n = 0;
        foreach ($extrato as $ent) {
            $n += count($ent['services']);
        }
        return $n;
    }

    /**
     * Recorta o extrato numa página de serviços (10 em 10), preservando a ordem
     * e os totais por entidade; entidades sem serviço na página saem da lista.
     */
    public static function sliceExtrato(array $extrato, int $offset, int $perPage): array
    {
        $out = [];
        $i   = 0;
        $end = $offset + $perPage;
        foreach ($extrato as $entId => $ent) {
            $keep = [];
            foreach ($ent['services'] as $svc) {
                if ($i >= $offset && $i < $end) {
                    $keep[] = $svc;
                }
                $i++;
            }
            if (!empty($keep)) {
                $ent['services'] = $keep;
                $out[$entId] = $ent;
            }
            if ($i >= $end) {
                break;
            }
        }
        return $out;
    }

    /** Total geral faturado no período (Faturamento financeiro). */
    public static function getFaturamentoTotal(string $startDt, string $endDt): float
    {
        $total = 0.0;
        foreach (self::getExtrato($startDt, $endDt) as $ent) {
            $total += $ent['summary']['total'];
        }
        return $total;
    }

    // =====================================================================
    //  Relatórios — renderização
    // =====================================================================

    /**
     * Relatório 1 — Extrato financeiro detalhado.
     *
     * @param array $extrato  saída de getExtrato()
     */
    public static function renderExtrato(array $extrato, string $exportCsvUrl, string $pdfUrl): void
    {
        // Tela inteira em negrito (pedido do cliente): envolve título, resumo da
        // entidade e os blocos de serviço — vale também na visão de impressão/PDF.
        echo "<div class='sr-extrato' style='font-weight:bold'>";
        echo "<div class='text-center mb-3'><h3 class='mb-0'>" . __('Extrato financeiro detalhado', 'servicereports') . "</h3></div>";

        echo "<div class='d-flex justify-content-end gap-2 mb-3'>";
        echo "<a href='" . Html::cleanInputText($exportCsvUrl) . "' class='btn btn-outline-success btn-sm'><i class='ti ti-file-spreadsheet me-1'></i>CSV</a>";
        echo "<a href='" . Html::cleanInputText($pdfUrl) . "' target='_blank' class='btn btn-outline-danger btn-sm'><i class='ti ti-file-type-pdf me-1'></i>PDF</a>";
        echo "</div>";

        if (empty($extrato)) {
            echo "<div class='alert alert-info'>" . __('Nenhum serviço encontrado para o período.', 'servicereports') . "</div>";
            echo "</div>";
            return;
        }

        foreach ($extrato as $ent) {
            $s = $ent['summary'];
            echo "<div class='card shadow-sm mb-4'><div class='card-body'>";
            echo "<h4 class='mb-3'>" . __('Detalhamento financeiro da entidade', 'servicereports') . ": <span class='text-primary'>" . $ent['name'] . "</span></h4>";
            self::renderEntitySummary($s);

            foreach ($ent['services'] as $svc) {
                self::renderServiceBlock($svc);
            }
            echo "</div></div>";
        }
        echo "</div>";
    }

    /** Resumo financeiro da entidade (mesmo bloco na tela e no PDF). */
    private static function renderEntitySummary(array $s): void
    {
        echo "<div class='mb-1'>" . __('Valor Monetário Total', 'servicereports') . ": " . self::money($s['total']) . "</div>";
        echo "<div>" . __('Somatório dos valores monetários fixos dos serviços contratados', 'servicereports') . ": " . self::money($s['fixos']) . "</div>";
        echo "<div>" . __('Somatório dos valores monetários das categorias dos serviços contratados', 'servicereports') . ": " . self::money($s['categorias']) . "</div>";
        echo "<div>" . __('Somatório dos valores monetários de hora dos serviços contratados', 'servicereports') . ": " . self::money($s['hora']) . "</div>";
        echo "<div>" . __('Somatório dos valores monetários extras relacionados a chamados', 'servicereports') . ": " . self::money($s['extras']) . "</div>";
        echo "<div>" . __('Somatório dos valores monetários dos ativos', 'servicereports') . ": " . self::money($s['ativos']) . "</div>";
        echo "<div>" . __('Tempo total de tarefas', 'servicereports') . ": " . self::duration((int) ($s['segundos'] ?? 0)) . "</div>";
    }

    /**
     * URL da logo usada no cabeçalho do PDF (vazio se o arquivo não existir).
     * Basta trocar `pics/instant-logo.png` para personalizar.
     */
    private static function logoUrl(): string
    {
        global $CFG_GLPI;

        foreach (['instant-logo.png', 'logo.png', 'logo.jpg', 'logo.svg'] as $file) {
            if (file_exists(GLPI_ROOT . '/plugins/servicereports/pics/' . $file)) {
                return $CFG_GLPI['root_doc'] . '/plugins/servicereports/pics/' . $file;
            }
        }
        return '';
    }

    /** Cabeçalho do PDF: logo discreta à esquerda + título e empresa. */
    private static function printHeader(string $entityName, string $start, string $end): void
    {
        $logo = self::logoUrl();

        // Logo ancorada à esquerda; título centralizado na página.
        echo "<div style='position:relative;min-height:60px;margin-bottom:24px'>";
        if ($logo !== '') {
            echo "<img src='" . Html::cleanInputText($logo) . "' alt='' style='position:absolute;left:0;top:0;height:56px;width:auto'>";
        }
        echo "<div style='text-align:center'>";
        echo "<div style='font-size:1.15rem'>" . __('Extrato de consumo de serviços', 'servicereports') . "</div>";
        echo "<div>" . sprintf(
            __('Período de %1$s a %2$s', 'servicereports'),
            Html::convDate($start),
            Html::convDate($end)
        ) . "</div>";
        echo "<div>" . __('Empresa', 'servicereports') . ": " . $entityName . "</div>";
        echo "</div></div>";
    }

    /**
     * Extrato na visão de impressão/PDF: cabeçalho com logo + título por
     * empresa (uma por página), sem os botões de CSV/PDF da tela.
     */
    public static function renderExtratoPrint(array $extrato, string $start, string $end): void
    {
        // Paisagem: a listagem de chamados tem 10 colunas e não cabe em retrato.
        echo "<style>@page { size: A4 landscape; margin: 10mm; }</style>";
        echo "<div class='sr-extrato' style='font-weight:bold'>";

        if (empty($extrato)) {
            self::printHeader('-', $start, $end);
            echo "<div class='alert alert-info'>" . __('Nenhum serviço encontrado para o período.', 'servicereports') . "</div>";
            echo "</div>";
            return;
        }

        $first = true;
        foreach ($extrato as $ent) {
            $s = $ent['summary'];
            echo "<div" . ($first ? '' : " style='page-break-before:always'") . ">";
            self::printHeader($ent['name'], $start, $end);

            self::renderEntitySummary($s);

            foreach ($ent['services'] as $svc) {
                self::renderServiceBlock($svc, true);
            }
            echo "</div>";
            $first = false;
        }
        echo "</div>";
    }

    /** Bloco de um serviço dentro do extrato (tela e visão de impressão). */
    private static function renderServiceBlock(array $svc, bool $print = false): void
    {
        global $CFG_GLPI;

        // Barra do serviço: nome à esquerda, custo total à direita.
        echo "<div class='mt-4'>";
        echo "<div style='background:#e9e9e9;padding:6px 10px;display:flex;justify-content:space-between;gap:12px'>";
        echo "<span>" . __('Serviço', 'servicereports') . ": " . $svc['name'] . "</span>";
        echo "<span style='white-space:nowrap'>" . __('CUSTO TOTAL', 'servicereports') . ": " . self::money($svc['total']) . "</span>";
        echo "</div>";

        // Valores do serviço em coluna única e, ao final, a listagem de chamados.
        echo "<div style='padding:6px 10px'>";
        echo "<div>" . __('Valor monetário mensal', 'servicereports') . ": " . self::money($svc['mensal']) . "</div>";
        echo "<div>" . __('Valor monetário de ativos', 'servicereports') . ": " . self::money($svc['ativos']) . "</div>";
        echo "<div>" . __('Valor monetário total por categoria de chamado', 'servicereports') . ": " . self::money($svc['categoria']) . "</div>";
        echo "<div>" . __('Valor monetário extras relacionados a chamados', 'servicereports') . ": " . self::money($svc['extras']) . "</div>";
        echo "<div>" . __('Valor monetário total das tarefas', 'servicereports') . ": " . self::money($svc['task_value']) . "</div>";
        echo "<div>" . __('Tempo total de tarefas', 'servicereports') . ": " . self::duration((int) $svc['task_seconds']) . "</div>";
        echo "</div>";

        self::renderTicketList($svc, $print);
        echo "</div>";
    }

    /**
     * Listagem dos chamados do serviço faturados no período — os **fechados**
     * dentro dele, com o tempo total de tarefas (nº vira link só fora do PDF).
     */
    private static function renderTicketList(array $svc, bool $print = false): void
    {
        global $CFG_GLPI;

        echo "<div style='padding:0 10px'><strong>" . __('Listagem dos chamados vinculados ao serviço', 'servicereports')
            . " <span style='font-weight:normal;font-size:.85rem'>(" . __('fechados no período', 'servicereports') . ")</span></strong></div>";

        if (empty($svc['tickets'])) {
            echo "<div style='padding:0 10px;font-size:.9rem'><i class='ti ti-alert-circle text-warning me-1'></i>" . __('Não há chamados vinculados ao serviço fechados no período', 'servicereports') . "</div>";
            // Causa mais comum de relatório zerado: não há por onde vincular chamados.
            if (empty($svc['cat']) && empty($svc['coveredassets'])) {
                echo "<div class='alert alert-warning mt-2 mb-2' style='font-size:.85rem'><i class='ti ti-info-circle me-1'></i>"
                    . __('O serviço não tem "Categoria de chamado" definida em Serviços Gerenciados nem ativos cobertos — sem um dos dois não há como vincular chamados, e os valores de hora/tarefa ficam zerados.', 'servicereports')
                    . "</div>";
            }
            return;
        }

        echo "<div class='table-responsive'><table class='table table-sm table-hover mb-2'>";
        echo "<thead><tr>"
            . "<th>" . __('ID', 'servicereports') . "</th>"
            . "<th>" . __('Título', 'servicereports') . "</th>"
            . "<th>" . __('Tipo', 'servicereports') . "</th>"
            . "<th>" . __('Categoria', 'servicereports') . "</th>"
            . "<th>" . __('Req.', 'servicereports') . "</th>"
            . "<th>" . __('Abertura', 'servicereports') . "</th>"
            . "<th>" . __('Fechamento', 'servicereports') . "</th>"
            . "<th class='text-end'>" . __('Horas', 'servicereports') . "</th>"
            . "<th class='text-end' style='white-space:nowrap'>" . __('Custo hora', 'servicereports') . "</th>"
            . "<th class='text-end' style='white-space:nowrap'>" . __('Custo chamado', 'servicereports') . "</th>"
            . "</tr></thead><tbody>";
        foreach ($svc['tickets'] as $t) {
            echo "<tr>";
            if ($print) {
                // No PDF o nº do chamado sai como texto (link não serve no papel).
                echo "<td>" . $t['id'] . "</td>";
            } else {
                $url = $CFG_GLPI['root_doc'] . '/front/ticket.form.php?id=' . $t['id'];
                echo "<td><a href='" . Html::cleanInputText($url) . "'>" . $t['id'] . "</a></td>";
            }
            echo "<td>" . $t['name'] . "</td>";
            echo "<td>" . Ticket::getTicketTypeName($t['type']) . "</td>";
            echo "<td>" . ($t['cat'] ? Dropdown::getDropdownName('glpi_itilcategories', $t['cat']) : '-') . "</td>";
            echo "<td>" . ($t['requester'] !== '' ? $t['requester'] : '-') . "</td>";
            echo "<td>" . Html::convDateTime($t['date']) . "</td>";
            echo "<td>" . ($t['closedate'] !== '' ? Html::convDateTime($t['closedate']) : '-') . "</td>";
            echo "<td class='text-end'>" . self::hms((int) $t['seconds']) . "</td>";
            echo "<td class='text-end' style='white-space:nowrap'>" . self::money((float) $t['cost_hour']) . "</td>";
            echo "<td class='text-end' style='white-space:nowrap'>" . self::money((float) $t['cost_total']) . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table></div>";
    }

    private static function kv(string $k, string $v): void
    {
        echo "<div class='col'><span class='text-muted'>$k:</span> <strong>$v</strong></div>";
    }

    /**
     * Relatório 2 — Faturamento financeiro (resumo do período).
     */
    public static function renderFaturamento(string $start, string $end, string $startDt, string $endDt, string $exportCsvUrl): void
    {
        $total = self::getFaturamentoTotal($startDt, $endDt);

        echo "<div class='text-center mb-3'>";
        echo "<h3 class='mb-0'>" . __('Faturamento financeiro', 'servicereports') . " ";
        echo "<a href='" . Html::cleanInputText($exportCsvUrl) . "' class='btn btn-link btn-sm p-0 align-baseline' title='CSV'><i class='ti ti-download'></i></a>";
        echo "</h3></div>";

        echo "<div class='card shadow-sm'><div class='card-body'>";
        echo "<h5 class='mb-2'>" . __('Resumo financeiro geral', 'servicereports') . "</h5>";
        echo "<div class='text-muted mb-2'>" . __('Período de pesquisa', 'servicereports') . ": "
            . Html::convDate($start) . " " . __('a', 'servicereports') . " " . Html::convDate($end) . "</div>";
        echo "<div><strong>" . __('Valor monetário total faturado', 'servicereports') . ":</strong> " . self::money($total) . "</div>";
        echo "</div></div>";
    }

    // =====================================================================
    //  Utilitários
    // =====================================================================

    public static function money(float $v): string
    {
        return 'R$ ' . number_format($v, 2, ',', '.');
    }

    /**
     * Segundos por extenso ("42 horas 0 minutos"), como no relatório original.
     * `use_days = false`: num extrato de serviços conta-se em horas, não em dias.
     */
    public static function duration(int $seconds): string
    {
        return Html::timestampToString(max(0, $seconds), false, false);
    }

    /** Segundos → HH:MM:SS. */
    public static function hms(int $seconds): string
    {
        $seconds = max(0, $seconds);
        return sprintf('%02d:%02d:%02d', intdiv($seconds, 3600), intdiv($seconds % 3600, 60), $seconds % 60);
    }

    /**
     * Renderiza um gráfico de barras horizontais simples (HTML/CSS, sem JS).
     *
     * @param array<int,array{label:string,value:float}> $data
     */
    public static function renderBarChart(array $data, string $title): void
    {
        echo "<div class='card h-100 shadow-sm'><div class='card-body'>";
        echo "<h3 class='h6 mb-3'>" . $title . "</h3>";
        if (empty($data)) {
            echo "<div class='text-muted text-center py-4'><i class='ti ti-alert-circle'></i> " . __('Sem dados para construir o gráfico.', 'servicereports') . "</div>";
        } else {
            $max = 0.0;
            foreach ($data as $d) {
                $max = max($max, $d['value']);
            }
            $max = $max > 0 ? $max : 1;
            foreach ($data as $d) {
                $pct = round($d['value'] / $max * 100);
                echo "<div class='mb-2'>";
                echo "<div class='d-flex justify-content-between' style='font-size:.8rem'>";
                echo "<span class='text-truncate' style='max-width:60%'>" . $d['label'] . "</span>";
                echo "<span class='text-muted'>" . self::money($d['value']) . "</span>";
                echo "</div>";
                echo "<div class='progress' style='height:10px'>";
                echo "<div class='progress-bar' role='progressbar' style='width:{$pct}%'></div>";
                echo "</div></div>";
            }
        }
        echo "</div></div>";
    }
}
